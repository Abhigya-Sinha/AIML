from flask import Flask, request, jsonify
import joblib
import numpy as np
from scipy.sparse import hstack

app = Flask(__name__)

# Load structural metrics helper
def extract_single_lexical(url):
    return np.array([[len(url), url.count('.'), url.count('-'), 1 if 'https' in url else 0]])

# Load the saved ML binaries
try:
    model = joblib.load('phishing_model.pkl')
    vectorizer = joblib.load('tfidf_vectorizer.pkl')
except FileNotFoundError:
    model, vectorizer = None, None

@app.route('/predict', methods=['POST'])
def predict():
    if not model or not vectorizer:
        return jsonify({"error": "Model files missing. Please run train.py first."}), 500
    
    data = request.get_json()
    if not data or 'url' not in data:
        return jsonify({"error": "Please provide a valid 'url' key in your JSON body."}), 400
    
    target_url = data['url']
    
    # NLP Matrix transform + Lexical stacking
    X_tfidf = vectorizer.transform([target_url])
    X_lexical = extract_single_lexical(target_url)
    X = hstack([X_tfidf, X_lexical])
    
    prediction = model.predict(X)[0]
    probabilities = model.predict_proba(X)[0]
    confidence = max(probabilities) * 100

    return jsonify({
        "url": target_url,
        "prediction": prediction,
        "confidence": f"{confidence:.2f}%"
    })

if __name__ == '__main__':
    # Starts server locally on port 5000
    app.run(host='0.0.0.0', port=5000, debug=True)