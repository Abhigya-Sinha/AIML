import sys
import joblib
import pandas as pd
import numpy as np
from scipy.sparse import hstack

def extract_single_lexical(url):
    # Extracts structure of a single live input URL
    url_len = len(url)
    dot_count = url.count('.')
    hyphen_count = url.count('-')
    is_https = 1 if 'https' in url else 0
    return np.array([[url_len, dot_count, hyphen_count, is_https]])

def predict_url(url):
    try:
        model = joblib.load('models/phishing_model.pkl')
        vectorizer = joblib.load('models/tfidf_vectorizer.pkl')
    except FileNotFoundError:
        print("Error: Model files not found. Run 'train.py' inside the container first!")
        return

    # Process live url
    X_tfidf = vectorizer.transform([url])
    X_lexical = extract_single_lexical(url)
    X = hstack([X_tfidf, X_lexical])
    
    # Run Inference
    prediction = model.predict(X)[0]
    probabilities = model.predict_proba(X)[0]
    classes = model.classes_
    
    prob_idx = np.where(classes == prediction)[0][0]
    confidence = probabilities[prob_idx] * 100

    print(f"\nTarget URL: {url}")
    print(f"Prediction: **{prediction.upper()}**")
    print(f"Confidence: {confidence:.2f}%")

if __name__ == "__main__":
    # Allows providing arguments via command line or defaults to a test URL
    input_url = sys.argv[1] if len(sys.argv) > 1 else "http://secure-paypal-login-verify-account.com/signin"
    predict_url(input_url)