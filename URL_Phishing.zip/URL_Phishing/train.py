import os
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from scipy.sparse import hstack
import numpy as np

def extract_lexical_features(urls):
    lengths = [len(str(u)) for u in urls]
    dots = [str(u).count('.') for u in urls]
    hyphens = [str(u).count('-') for u in urls]
    https = [1 if 'https' in str(u) else 0 for u in urls]
    return np.column_stack((lengths, dots, hyphens, https))

def main():
    print("Generating simulated phishing dataset training data...")
    # Clean fallback dataset to build the template requirements instantly
    data = {
        'url': [
            'https://www.google.com', 'https://github.com', 'https://www.amazon.com',
            'http://secure-login-paypal.com/signin', 'http://verify-netflix-billing.xyz',
            'http://update-your-bank-password.net', 'https://www.wikipedia.org'
        ] * 100,
        'type': ['benign', 'benign', 'benign', 'phishing', 'phishing', 'phishing', 'benign'] * 100
    }
    df = pd.DataFrame(data)
    df['label'] = df['type'].apply(lambda x: 'benign' if x == 'benign' else 'malicious')

    print("Extracting NLP and structural features...")
    vectorizer = TfidfVectorizer(analyzer='char', ngram_range=(3, 4), max_features=1000)
    X_tfidf = vectorizer.fit_transform(df['url'])
    X_lexical = extract_lexical_features(df['url'])
    X = hstack([X_tfidf, X_lexical])
    y = df['label']

    print("Fitting Classifier...")
    model = RandomForestClassifier(n_estimators=10, max_depth=10, random_state=42)
    model.fit(X, y)

    print("Exporting your model binary artifacts (.pkl)...")
    joblib.dump(model, 'phishing_model.pkl')
    joblib.dump(vectorizer, 'tfidf_vectorizer.pkl')
    print("Success! Your '.pkl' files have been successfully created.")

if __name__ == "__main__":
    main()